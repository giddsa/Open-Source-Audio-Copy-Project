# XTTS + SILMA F5 Voice Studio — No RVC

هذا الإصدار يلغي RVC بالكامل.

## المحركات
- XTTS v2: المحرك الأساسي، ويدعم العربية واللغات المتعددة.
- SILMA F5 v1 Base: محرك إضافي للمقارنة، والنموذج الرسمي الحالي هنا مخصص للإنجليزية والصينية.
- Dual/Ensemble: يولّد مرشحين من **نفس العينة المرجعية + نفس النص**. لا يتم تمرير خرج F5 إلى XTTS لأن XTTS ليس Voice Converter.

## تشغيل
```bash
chmod +x setup_lightning.sh setup_f5.sh run_lightning.sh
./setup_lightning.sh
./setup_f5.sh
./run_lightning.sh
```

إذا كان الهدف هو العربية مع F5، استخدم نموذج F5 عربي متوافق وضع إعدادات checkpoint/vocab الخاصة به بدل نموذج F5TTS_v1_Base.


## تشغيل على CPU — 4 vCPU / 16 GB RAM

هذا الإصدار يحتوي على تشغيل مخصص للـCPU. لا يحتاج T4 أو أي GPU.

```bash
chmod +x setup_cpu.sh run_cpu.sh
./setup_cpu.sh
./run_cpu.sh
```

الإعداد الافتراضي يجبر XTTS على CPU عبر `FORCE_CPU=1`.
إذا كان FFmpeg غير موجود، يجب تثبيته في بيئة الـStudio حتى تعمل جميع صيغ رفع وتحويل الصوت.

**ملاحظة الأداء:** XTTS-v2 وSILMA/F5 على CPU أبطأ بكثير من T4. استخدم `fidelity=fast` عند الحاجة إلى تجربة أسرع، واحتفظ بـ`high` لأفضل مطابقة ممكنة.
